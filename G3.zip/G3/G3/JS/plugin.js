// JavaScript Document

function mobilmenu() {
	var x = document.getElementById("mobilMenu");
		if (x.style.display === "block") {
		x.style.display = "none";
		} 
		else {
			x.style.display = "block";
			}
		};

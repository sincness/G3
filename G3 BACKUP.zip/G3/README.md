# G3
Gruppe 3 


Blomsterbutik


[KRAV]
Farver - Lyse pastel farver - gul, lyserød og lyseblå
Font - Cursive for title - OpenSans

Roadmap - 


Release - 
Onsdag  (est. 12.00)


Product Owner - Zennia

Scrum Master - Malthe

Scrum Team - Zennia, Malthe, Mikkel, Hans Kristian og Kristina.







Hos Blomsterbutikken har vi mange års erfaring med blomstermarkedet. Hvert årti, har på hver sin måde været med til at skabe det brand, som vi kender i dag. Det netværk af florister, der i starten gjorde det muligt at levere blomster landet og verden over, udgør stadig rygraden i Interflora, og de 341 lokale blomsterbutikker er en afgørende del af den velfungerende organisation, som vi ser i dag.
